﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Speech.Synthesis;
using System.Xml.Linq;

namespace Herrera_CRUD_Nanaman
{
    public partial class MainForm: Form
    {
        SpeechSynthesizer speak = new SpeechSynthesizer();
        public MainForm()
        {
            InitializeComponent();
            this.KeyPreview = true;
        }

        private void btnAdd_Student_Click(object sender, EventArgs e)
        {
            string name = txtFullName.Text;
            string student_id = txtStudent_ID.Text;
            string course = txtCourse.Text;
            string year_level = cmbYear_Level.Text;
            string contact = txtContact.Text;

            if (name == "" || student_id == "" || course == "" || year_level == "" || contact == "")
            {
                speak.SpeakAsync("PLease fill all fields");
                MessageBox.Show("Please fill all fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                using (var conn = Database.Get())
                {
                    conn.Open();
                    string query = "INSERT INTO tblStudent_Info (Name, Student_id, Course, Year_Level, Contact_Number) " +
                        "VALUES (@Name, @Student_ID, @Course, @Year_Level, @Contact_Number)";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Student_id", student_id);
                        cmd.Parameters.AddWithValue("@Course", course);
                        cmd.Parameters.AddWithValue("@Year_Level", year_level);
                        cmd.Parameters.AddWithValue("@Contact_Number", contact);

                        cmd.ExecuteNonQuery();
                        speak.SpeakAsync("student information added successfully");
                        MessageBox.Show("Student Info Added Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Adding Record: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            AddInfo();
            txtFullName.Clear();
            txtStudent_ID.Clear();
            txtCourse.Clear();
            cmbYear_Level.SelectedIndex = -1;
            txtContact.Clear();
        }

        private void AddInfo()
        {
            using (var conn = Database.Get())
            {
                conn.Open();
                string query = "SELECT * FROM tblStudent_Info";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    using (var adapter = new MySqlDataAdapter(cmd))
                    {
                        var table = new System.Data.DataTable();
                        adapter.Fill(table);
                        dgvStudent.DataSource = table;
                    }
                }
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            AddInfo();
            speak.SpeakAsync("Hi Welcome Please Enter Your FullName, Your ID, Course, Yeal Level, and Contact Number");
            speak.Rate = -3;
        }

        private void btnDelete_Info_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvStudent.SelectedRows.Count == 0)
                {
                    speak.SpeakAsync("Please select a record to delete");
                    MessageBox.Show("Please select a record to delete", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int ID = Convert.ToInt32(dgvStudent.SelectedRows[0].Cells["ID"].Value);
                speak.SpeakAsync("Are you sure you want to delete this?");

                DialogResult result = MessageBox.Show("Are you sure you want to delete this?", "Confrim Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    using (var conn = Database.Get())
                    {
                        conn.Open();
                        string query = "DELETE FROM tblStudent_Info WHERE ID =@ID";

                        using (var cmd = new MySqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@ID", ID);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                else
                {
                    return;
                }
                speak.SpeakAsync("Record deleted successfuly");
                MessageBox.Show("Record Deleted Successfully", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AddInfo();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Deleting Record" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Info_Click(object sender, EventArgs e)
        {
            string name = txtFullName.Text;
            string student_id = txtStudent_ID.Text;
            string course = txtCourse.Text;
            string year_level = cmbYear_Level.Text;
            string contact = txtContact.Text;

            try
            {
                using (var conn = Database.Get())
                {
                    conn.Open();
                    string query = @"UPDATE tblStudent_Info SET Name = @Name, Course = @Course, Year_Level = @Year_Level, Contact_Number = @Contact_Number WHERE Student_ID = @Student_ID";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Student_id", student_id);
                        cmd.Parameters.AddWithValue("@Course", course);
                        cmd.Parameters.AddWithValue("@Year_Level", year_level);
                        cmd.Parameters.AddWithValue("@Contact_Number", contact);

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            speak.SpeakAsync("Student Info Updated Successfully");
                            MessageBox.Show("Student Info Updated Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            speak.SpeakAsync("Invalid Student ID");
                            MessageBox.Show("Invalid Student ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                AddInfo();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Updating Record" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSearch_Info_Click(object sender, EventArgs e)
        {
            try
            {
                using (var conn = Database.Get())
                {
                    conn.Open();
                    string query = "SELECT * FROM tblStudent_Info WHERE Name = @Name || Student_id = @Student_id";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Student_ID", txtSearch.Text);
                        cmd.Parameters.AddWithValue("@Name", txtSearch.Text);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string name = reader["Name"].ToString();
                                string id = reader["Student_Id"].ToString();
                                string course = reader["Course"].ToString();
                                string year_level = reader["Year_Level"].ToString();
                                string contact = reader["Contact_Number"].ToString();
                                speak.SpeakAsync("Student Name," + name + "Student ID," + id);
                                speak.Rate = -3;
                                MessageBox.Show("Student Information\n\n" + $"Student Name: {name}\n" + $"Student ID: {id}\n" + $"Course: {course}\n" + $"Year Level: {year_level}\n" + $"Contact Number: {contact}", "Student Found", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            }
                            else
                            {
                                speak.SpeakAsync("No Record Found");
                                MessageBox.Show("No Record Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }

                AddInfo();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Searching Record" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtFullName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtStudent_ID.Focus();
            }
        }

        private void txtStudent_ID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtCourse.Focus();
            }
        }

        private void txtCourse_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                cmbYear_Level.Focus();
            }
        }

        private void cmbYear_Level_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtContact.Focus();
            }
        }

        private void txtContact_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                btnAdd_Student.Focus();
            }
        }

        private void btnUpdate_Info_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Control && e.KeyCode == Keys.Space)
            {
                e.SuppressKeyPress = true;
                btnUpdate_Info.PerformClick();
            }
        }

        private void txtFullName_Leave(object sender, EventArgs e)
        {
            if(txtFullName.Text == "")
            {
                txtFullName.BackColor = Color.Red;
            }
            else
            {
                txtFullName.BackColor = Color.LightPink;
            }
        }

        private void txtStudent_ID_Leave(object sender, EventArgs e)
        {
            if (txtStudent_ID.Text == "")
            {
                txtStudent_ID.BackColor = Color.Red;
            }
            else
            {
                txtStudent_ID.BackColor = Color.LightPink;
            }
        }

        private void txtCourse_Leave(object sender, EventArgs e)
        {
            if (txtCourse.Text == "")
            {
                txtCourse.BackColor = Color.Red;
            }
            else
            {
                txtCourse.BackColor = Color.LightPink;
            }
        }

        private void cmbYear_Level_Leave(object sender, EventArgs e)
        {
            if (cmbYear_Level.Text == "")
            {
                cmbYear_Level.BackColor = Color.Red;
            }
            else
            {
                cmbYear_Level.BackColor = Color.LightPink;
            }
        }

        private void txtContact_Leave(object sender, EventArgs e)
        {
            if (txtContact.Text == "")
            {
                txtContact.BackColor = Color.Red;
            }
            else
            {
                txtContact.BackColor = Color.LightPink;
            }
        }
    }
}
