﻿namespace Herrera_CRUD_Nanaman
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtStudent_ID = new System.Windows.Forms.TextBox();
            this.txtCourse = new System.Windows.Forms.TextBox();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.cmbYear_Level = new System.Windows.Forms.ComboBox();
            this.dgvStudent = new System.Windows.Forms.DataGridView();
            this.btnAdd_Student = new System.Windows.Forms.Button();
            this.btnDelete_Info = new System.Windows.Forms.Button();
            this.btnUpdate_Info = new System.Windows.Forms.Button();
            this.btnSearch_Info = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(209, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(903, 51);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student Information Management(CRUD)";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightPink;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1291, 100);
            this.panel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 28);
            this.label2.TabIndex = 2;
            this.label2.Text = "Enter Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(205, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = "Enter Student_Id";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 242);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 28);
            this.label4.TabIndex = 4;
            this.label4.Text = "Enter Course";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 291);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(203, 28);
            this.label5.TabIndex = 5;
            this.label5.Text = "Enter Year Level";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 337);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(215, 28);
            this.label6.TabIndex = 6;
            this.label6.Text = "Enter Contact_No";
            // 
            // txtFullName
            // 
            this.txtFullName.BackColor = System.Drawing.Color.LightPink;
            this.txtFullName.Location = new System.Drawing.Point(255, 129);
            this.txtFullName.Multiline = true;
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(226, 36);
            this.txtFullName.TabIndex = 7;
            this.txtFullName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtFullName_KeyDown);
            this.txtFullName.Leave += new System.EventHandler(this.txtFullName_Leave);
            // 
            // txtStudent_ID
            // 
            this.txtStudent_ID.BackColor = System.Drawing.Color.LightPink;
            this.txtStudent_ID.Location = new System.Drawing.Point(255, 189);
            this.txtStudent_ID.Multiline = true;
            this.txtStudent_ID.Name = "txtStudent_ID";
            this.txtStudent_ID.Size = new System.Drawing.Size(226, 36);
            this.txtStudent_ID.TabIndex = 8;
            this.txtStudent_ID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtStudent_ID_KeyDown);
            this.txtStudent_ID.Leave += new System.EventHandler(this.txtStudent_ID_Leave);
            // 
            // txtCourse
            // 
            this.txtCourse.BackColor = System.Drawing.Color.LightPink;
            this.txtCourse.Location = new System.Drawing.Point(255, 240);
            this.txtCourse.Multiline = true;
            this.txtCourse.Name = "txtCourse";
            this.txtCourse.Size = new System.Drawing.Size(226, 36);
            this.txtCourse.TabIndex = 9;
            this.txtCourse.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCourse_KeyDown);
            this.txtCourse.Leave += new System.EventHandler(this.txtCourse_Leave);
            // 
            // txtContact
            // 
            this.txtContact.BackColor = System.Drawing.Color.LightPink;
            this.txtContact.Location = new System.Drawing.Point(255, 329);
            this.txtContact.Multiline = true;
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(226, 36);
            this.txtContact.TabIndex = 10;
            this.txtContact.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtContact_KeyDown);
            this.txtContact.Leave += new System.EventHandler(this.txtContact_Leave);
            // 
            // cmbYear_Level
            // 
            this.cmbYear_Level.BackColor = System.Drawing.Color.LightPink;
            this.cmbYear_Level.FormattingEnabled = true;
            this.cmbYear_Level.Items.AddRange(new object[] {
            "First Year",
            "Second Year",
            "Third Year",
            "Fourth Year"});
            this.cmbYear_Level.Location = new System.Drawing.Point(255, 291);
            this.cmbYear_Level.Name = "cmbYear_Level";
            this.cmbYear_Level.Size = new System.Drawing.Size(226, 28);
            this.cmbYear_Level.TabIndex = 11;
            this.cmbYear_Level.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbYear_Level_KeyDown);
            this.cmbYear_Level.Leave += new System.EventHandler(this.cmbYear_Level_Leave);
            // 
            // dgvStudent
            // 
            this.dgvStudent.BackgroundColor = System.Drawing.Color.LightPink;
            this.dgvStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudent.Location = new System.Drawing.Point(525, 127);
            this.dgvStudent.Name = "dgvStudent";
            this.dgvStudent.RowHeadersWidth = 62;
            this.dgvStudent.RowTemplate.Height = 28;
            this.dgvStudent.Size = new System.Drawing.Size(741, 424);
            this.dgvStudent.TabIndex = 12;
            // 
            // btnAdd_Student
            // 
            this.btnAdd_Student.BackColor = System.Drawing.Color.LightPink;
            this.btnAdd_Student.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd_Student.Location = new System.Drawing.Point(4, 398);
            this.btnAdd_Student.Name = "btnAdd_Student";
            this.btnAdd_Student.Size = new System.Drawing.Size(156, 52);
            this.btnAdd_Student.TabIndex = 13;
            this.btnAdd_Student.Text = "Add_Info";
            this.btnAdd_Student.UseVisualStyleBackColor = false;
            this.btnAdd_Student.Click += new System.EventHandler(this.btnAdd_Student_Click);
            // 
            // btnDelete_Info
            // 
            this.btnDelete_Info.BackColor = System.Drawing.Color.LightPink;
            this.btnDelete_Info.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete_Info.Location = new System.Drawing.Point(176, 398);
            this.btnDelete_Info.Name = "btnDelete_Info";
            this.btnDelete_Info.Size = new System.Drawing.Size(156, 52);
            this.btnDelete_Info.TabIndex = 14;
            this.btnDelete_Info.Text = "Delete";
            this.btnDelete_Info.UseVisualStyleBackColor = false;
            this.btnDelete_Info.Click += new System.EventHandler(this.btnDelete_Info_Click);
            // 
            // btnUpdate_Info
            // 
            this.btnUpdate_Info.BackColor = System.Drawing.Color.LightPink;
            this.btnUpdate_Info.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate_Info.Location = new System.Drawing.Point(348, 398);
            this.btnUpdate_Info.Name = "btnUpdate_Info";
            this.btnUpdate_Info.Size = new System.Drawing.Size(156, 52);
            this.btnUpdate_Info.TabIndex = 15;
            this.btnUpdate_Info.Text = "Update";
            this.btnUpdate_Info.UseVisualStyleBackColor = false;
            this.btnUpdate_Info.Click += new System.EventHandler(this.btnUpdate_Info_Click);
            this.btnUpdate_Info.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnUpdate_Info_KeyDown);
            // 
            // btnSearch_Info
            // 
            this.btnSearch_Info.BackColor = System.Drawing.Color.LightPink;
            this.btnSearch_Info.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch_Info.Location = new System.Drawing.Point(12, 470);
            this.btnSearch_Info.Name = "btnSearch_Info";
            this.btnSearch_Info.Size = new System.Drawing.Size(156, 52);
            this.btnSearch_Info.TabIndex = 16;
            this.btnSearch_Info.Text = "Search";
            this.btnSearch_Info.UseVisualStyleBackColor = false;
            this.btnSearch_Info.Click += new System.EventHandler(this.btnSearch_Info_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.LightPink;
            this.txtSearch.Location = new System.Drawing.Point(201, 477);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(226, 36);
            this.txtSearch.TabIndex = 17;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1291, 590);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnSearch_Info);
            this.Controls.Add(this.btnUpdate_Info);
            this.Controls.Add(this.btnDelete_Info);
            this.Controls.Add(this.btnAdd_Student);
            this.Controls.Add(this.dgvStudent);
            this.Controls.Add(this.cmbYear_Level);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtCourse);
            this.Controls.Add(this.txtStudent_ID);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.KeyPreview = true;
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.TextBox txtStudent_ID;
        private System.Windows.Forms.TextBox txtCourse;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.ComboBox cmbYear_Level;
        private System.Windows.Forms.DataGridView dgvStudent;
        private System.Windows.Forms.Button btnAdd_Student;
        private System.Windows.Forms.Button btnDelete_Info;
        private System.Windows.Forms.Button btnUpdate_Info;
        private System.Windows.Forms.Button btnSearch_Info;
        private System.Windows.Forms.TextBox txtSearch;
    }
}

