﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Speech.Synthesis;

namespace Herrera_CRUD_Nanaman
{
    class Database
    {
        private static string Connection = "server=localhost;uid=root;pwd=admin123;database=student_info_db;";

        public static MySqlConnection Get()
        {
            return new MySqlConnection(Connection);
        }
    }
}
